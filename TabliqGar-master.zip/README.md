# [TabLiqGar V.3 ](https://telegram.me/CerNerTabliqGar)

* * *


# نصب ربات
```sh
cd $HOME
git clone https://github.com/CodeLua/TabLiqGar.git
cd TabLiqGar
chmod +x install
chmod +x start
./install
./start
# سپس شماره و کد را ارسال کنید :)
# اجرای اتولانچ:
cd TabLiqGar
chmod 777 screen
chmod +x install
./install
screen ./screen
```
#نصب ربات api

```sh
ابتدا توکن ربات خود را در فایل apistart در خط 4 قرار دهید و سپس دستور زیر را وارد کنید 
nohup ./apistart
```
### نصب آسان
```sh
git clone https://github.com/CodeLua/TabLiqGar.git && cd TabLiqGar && chmod +x install && chmod +x start && ./install && ./start

نصب آ سان اتولانچ

git clone https://github.com/CodeLua/TabLiqGar.git && cd TabLiqGar && chmod 777 screen && chmod +x install && ./install screen ./screen

* * *
```
# نویسنده!

[Amir](https://telegram.me/CodeLua)

### کانال تیم:

[CerNer Team](https://telegram.me/CerNer_Tm)
